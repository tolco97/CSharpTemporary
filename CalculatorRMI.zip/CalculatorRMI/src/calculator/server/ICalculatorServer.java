package calculator.server;

import java.rmi.Remote;
import java.rmi.RemoteException;

import calculator.model.ICalculator;

public interface ICalculatorServer extends Remote {

	ICalculator getCalculator() throws RemoteException;

}
