package calculator.server;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

import calculator.model.ICalculator;
import calculator.model.RemoteCalculator;

public class CalculatorServer extends UnicastRemoteObject implements ICalculatorServer {

	private static final long serialVersionUID = 1L;

	protected CalculatorServer() throws RemoteException {
		super();
	}

	@Override
	public ICalculator getCalculator() throws RemoteException {
		return new RemoteCalculator();
	}

}
