package calculator.server;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class CalculatorServer extends UnicastRemoteObject implements ICalculatorServer {

	private static final long serialVersionUID = 1L;

	protected CalculatorServer() throws RemoteException {
		super();
	}

	@Override
	public int add(int a, int b) throws RemoteException {
		return a + b;
	}

	@Override
	public int subtract(int a, int b) throws RemoteException {
		return a - b;
	}

	@Override
	public int multiply(int a, int b) throws RemoteException {
		return a * b;
	}

	@Override
	public int divide(int a, int b) throws RemoteException {
		return a / b;
	}

}
