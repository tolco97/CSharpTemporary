package calculator.model;

import java.io.Serializable;

public interface ICalculator extends Serializable {

	int add(int a, int b);

	int subtract(int a, int b);

	int multiply(int a, int b);

	int divide(int a, int b);

}
