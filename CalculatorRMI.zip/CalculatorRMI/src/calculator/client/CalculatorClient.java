package calculator.client;

import static org.junit.Assert.assertEquals;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;

import org.junit.Before;
import org.junit.Test;

import calculator.server.ICalculatorServer;

public class CalculatorClient {
	private ICalculatorServer server;

	@Before
	public void setUp() throws MalformedURLException, RemoteException, NotBoundException {
		server = (ICalculatorServer) Naming.lookup("CalculatorServer");
	}

	@Test
	public void testAdd() throws RemoteException {
		assertEquals(server.add(5, 5), 10);
	}

	@Test
	public void testSubtract() throws RemoteException {
		assertEquals(server.subtract(5, 5), 0);
	}

	@Test
	public void testMultiply() throws RemoteException {
		assertEquals(server.multiply(5, 5), 25);
	}

	@Test
	public void testDivide() throws RemoteException {
		assertEquals(server.divide(25, 5), 5);
	}

}
