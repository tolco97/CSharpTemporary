package calculator.client;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;

import org.junit.Before;
import org.junit.Test;

import calculator.model.ICalculator;
import calculator.server.ICalculatorServer;

public class CalculatorClient {
	private ICalculatorServer server;
	private ICalculator calculator;

	@Before
	public void setUp() throws MalformedURLException, RemoteException, NotBoundException {
		server = (ICalculatorServer) Naming.lookup("CalculatorServer");
		calculator = server.getCalculator();
	}

	@Test
	public void testRemoteObjectType() throws RemoteException {
		assertTrue(server instanceof ICalculatorServer);
		assertFalse(server instanceof CalculatorClient);
		assertTrue(calculator instanceof ICalculator);
		assertFalse(calculator instanceof ICalculatorServer);
	}

	@Test
	public void testAdd() throws RemoteException {
		assertEquals(calculator.add(5, 5), 10);
	}

	@Test
	public void testSubtract() throws RemoteException {
		assertEquals(calculator.subtract(5, 5), 0);
	}

	@Test
	public void testMultiply() throws RemoteException {
		assertEquals(calculator.multiply(5, 5), 25);
	}

	@Test
	public void testDivide() throws RemoteException {
		assertEquals(calculator.divide(25, 5), 5);
	}

}
