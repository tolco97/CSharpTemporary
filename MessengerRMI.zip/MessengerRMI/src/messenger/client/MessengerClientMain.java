package messenger.client;

import java.net.MalformedURLException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;

import messenger.model.Message;

public class MessengerClientMain {

	public static void main(String[] args) throws RemoteException, MalformedURLException, NotBoundException {
		IMessengerClient client = new MessengerClient("Stoyan");
		client.sendMessage(new Message("Stoyan", "Anatoli", "Sup"));
	}

}
