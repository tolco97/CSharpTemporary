package messenger.client;

import java.rmi.Remote;
import java.rmi.RemoteException;

import messenger.model.Message;

public interface IMessengerClient extends Remote {
	
	void sendMessage(Message msg) throws RemoteException;

	String getClientName() throws RemoteException;
	
	void recieveMessage(Message msg) throws RemoteException;
	
}
