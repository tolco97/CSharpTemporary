package messenger.client;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.List;
import java.util.Objects;

import messenger.model.Message;
import messenger.server.IMessengerServer;
import messenger.server.MessengerServerMain;

public class MessengerClient extends UnicastRemoteObject implements IMessengerClient {

	private static final long serialVersionUID = 1L;
	private String clientName;
	private List<IMessengerClient> clientList;
	private IMessengerServer server;

	protected MessengerClient(String clientName) throws RemoteException, MalformedURLException, NotBoundException {
		super();
		this.clientName = clientName;
		server = (IMessengerServer) Naming.lookup(MessengerServerMain.SERVER_REFERENCE_NAME);
		server.addClient(this);
		clientList = server.getClientList();
	}

	@Override
	public void sendMessage(Message msg) throws RemoteException {
		String recieverName = msg.getRecieverName(), currentClientName = null;
		for (IMessengerClient currentClient : clientList) {
			currentClientName = currentClient.getClientName();
			if (Objects.equals(recieverName, currentClientName)) {
				currentClient.recieveMessage(msg);
			}
		}
	}

	@Override
	public String getClientName() {
		return clientName;
	}

	@Override
	public void recieveMessage(Message msg) throws RemoteException {
		System.out.println(msg);
	}

}
