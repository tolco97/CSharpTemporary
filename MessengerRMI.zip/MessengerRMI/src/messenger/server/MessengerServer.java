package messenger.server;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.List;

import messenger.client.IMessengerClient;

public class MessengerServer extends UnicastRemoteObject implements IMessengerServer {

	private static final long serialVersionUID = 1L;
	private List<IMessengerClient> clientList;

	protected MessengerServer() throws RemoteException {
		super();
		clientList = new ArrayList<>();
	}

	@Override
	public void addClient(IMessengerClient newClient) throws RemoteException {
		clientList.add(newClient);
		System.out.println(newClient.getClientName() + " connected!");
	}

	@Override
	public void removeClient(IMessengerClient client) throws RemoteException {
		clientList.remove(client);
		System.out.println(client.getClientName() + " disconnected!");
	}

	@Override
	public List<IMessengerClient> getClientList() throws RemoteException {
		List<IMessengerClient> clients = new ArrayList<>();
		clients.addAll(clientList);
		return clients;
	}

}
