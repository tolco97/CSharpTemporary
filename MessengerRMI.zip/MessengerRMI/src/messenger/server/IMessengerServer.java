package messenger.server;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;

import messenger.client.IMessengerClient;

public interface IMessengerServer extends Remote {
	
	void addClient(IMessengerClient newClient) throws RemoteException;
	
	void removeClient(IMessengerClient client) throws RemoteException;
	
	List<IMessengerClient> getClientList() throws RemoteException;
	
}
