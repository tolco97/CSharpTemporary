package messenger.server;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;

public class MessengerServerMain {

	public static final String SERVER_REFERENCE_NAME = "MessengerServer";
	
	public static void main(String[] args) {
		try {
			IMessengerServer server = new MessengerServer();
			LocateRegistry.createRegistry(1099);
			Naming.rebind(SERVER_REFERENCE_NAME, server);
		} catch (RemoteException | MalformedURLException e) {
			e.printStackTrace();
		}
	}

}
