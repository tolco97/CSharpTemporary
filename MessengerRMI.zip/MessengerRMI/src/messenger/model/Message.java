package messenger.model;

import java.io.Serializable;
import java.util.Date;

public class Message implements Serializable {

	private static final long serialVersionUID = 1L;

	private String senderName, recieverName, messageContent;
	private Date createdOn;

	public Message(String senderName, String recieverName, String messageContent) {
		this.senderName = senderName;
		this.recieverName = recieverName;
		this.messageContent = messageContent;
		createdOn = new Date();
	}

	public String getRecieverName() {
		return recieverName;
	}

	public String getMessageContent() {
		return messageContent;
	}

	public String getSenderName() {
		return senderName;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	@Override
	public String toString() {
		return String.format("[%s] %s: %s", getCreatedOn(), getSenderName(), getMessageContent());
	}

}
